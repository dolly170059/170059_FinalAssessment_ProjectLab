package ebook;

import java.util.Scanner;

import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

/*******
 * <p> Title: UserInterface Class. </p>
 * 
 * <p> Description: A JavaFX demonstration application: This controller class describes the user
 * interface for the Exercise04 demonstration application </p>
 * 
 * <p> Copyright: Lynn Robert Carter � 2018-08-04 </p>
 * 
 * @author Dolly Chandel 
 * 
 * @version 2.03	2018-07-19 Baseline
 * @version 3.00	2018-08-04 An enhancement for Exercise 04
 * 
 */
public class UserInterface {
	//Attributes
  private Label main = new Label("Ebook Project");
  private TextField txt_roll = new TextField();
  private TextField txt_digit = new TextField();
  private TextField txt_result = new TextField();
  private Button enter = new Button("Enter");
  private Label rollno = new Label("Roll Number");
  private Label digit = new Label("Decimal digit");
  private Label final_result = new Label("Result");
  private Label error_message = new Label("");
  
	/**********************************************************************************************

	Constructors
	
	**********************************************************************************************/

	/**********
	 * This constructor established the user interface with all of the graphical widgets that are
	 * use to make the user interface work.
	 * 
	 * @param theRoot	This parameter is the Pane that JavaFX expects the application to use when
	 * 					it sets up the GUI elements.
	 */
	public UserInterface(Pane theRoot) {

		
		// Calling a function to regular validate the error term for operand 1
		setupTextUI(txt_roll, "Arial", 18, 280, Pos.BASELINE_LEFT, 200, 70, true);
		
		// Calling a function to regular validate the error term for operand 1
		setupTextUI(txt_digit, "Arial", 18, 280, Pos.BASELINE_LEFT, 200, 140, true);
				
		// Calling a function to regular validate the error term for operand 1
		setupTextUI(txt_result, "Arial", 18, 280, Pos.BASELINE_LEFT, 200, 210, true);
				
		
		setupLabelUI(main, "Arial", 22, Mainline.WINDOW_WIDTH-20, Pos.BASELINE_LEFT, 
				270, 10);
		
		setupLabelUI(rollno, "Arial", 18, Mainline.WINDOW_WIDTH-20, Pos.BASELINE_LEFT, 
				50, 70);
		
		setupLabelUI(digit, "Arial", 18, Mainline.WINDOW_WIDTH-20, Pos.BASELINE_LEFT, 
				50, 140);
		
		setupLabelUI(final_result, "Arial", 18, Mainline.WINDOW_WIDTH-20, Pos.BASELINE_LEFT, 
				50, 210);
		
		setupLabelUI(error_message, "Arial", 18, Mainline.WINDOW_WIDTH-20, Pos.BASELINE_LEFT, 
				150, 270);
		error_message.setTextFill(Color.RED);
		
		setupButtonUI(enter, "Arial", 18, 70, Pos.BASELINE_LEFT, 500,  210);
		enter.setOnAction((event) -> { final_result(); });
		
		// Place all of the just-initialized GUI elements into the pane with the exception of the
		// Stop button.  That widget will replace the Start button, once the Start has been pressed
		theRoot.getChildren().addAll(txt_roll, txt_digit, txt_result, main, enter,
				rollno, digit,error_message,  final_result);
	}

	
	/**********************************************************************************************

	Helper methods - Used to set up the JavaFX widgets and simplify the code above
	
	**********************************************************************************************/

	private void final_result() {
		if(txt_roll.getText().isEmpty()) {
			error_message.setText("Enter Your Roll Number");
		}
		else if(check(txt_roll.getText()) == false) {
			error_message.setText("correct the first input (integer)");
		}
		else if(txt_digit.getText().isEmpty()) {
			error_message.setText("Enter decimal digit number");
		}
		else if(check(txt_digit.getText()) == false) {
			error_message.setText("correct the second input (integer)");
		}
		else if(digitNum(txt_digit.getText())>2) {
			error_message.setText("Enter the two decimal only");
		}
		else {
			int finall = Integer.parseInt(txt_roll.getText()) - Integer.parseInt(txt_digit.getText());
			txt_result.setText(Integer.toString(finall));
		}
	}

	private boolean check(String num) {
		 try 
	        { 
	            // checking valid integer using parseInt() method 
	            Integer.parseInt(num); 
	           return true;
	        }  
	        catch (NumberFormatException e) 
	        { 
	            return false;
	        } 
	}
	

public int digitNum(String string) {
	int Number, Count=0;
	
	Scanner sc = new Scanner (string);	
	
	Number = sc.nextInt();
	
	while(Number > 0) {
		Number = Number / 10;
		Count = Count + 1; 
	}
	return Count;
}
	/**********
	 * Private local method to initialize the standard fields for a label
	 */
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y){
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a text field
	 */
	private void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y, boolean e){
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);		
		t.setEditable(e);
	}
	


	/**********
	 * Private local method to initialize the standard fields for a button
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y){
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);		
	}
	
	
	

}
