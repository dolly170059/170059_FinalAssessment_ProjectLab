package ebook;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class Mainline {

	
	public final static double WINDOW_WIDTH = 850;
	public final static double WINDOW_HEIGHT = 550;
	
	
	public void start(Stage theStage) {
		theStage.setTitle("Ebook Project");												
		Pane theRoot = new Pane();														
		new UserInterface(theRoot);
		Scene theScene = new Scene(theRoot, WINDOW_WIDTH, WINDOW_HEIGHT);				
		theStage.setScene(theScene);													
		theStage.show();
	}
		public static void main(String[] args) {										
		launch(args);																	
	}																					
		private static void launch(String[] args) {
			// TODO Auto-generated method stub
			
		}
	
}

